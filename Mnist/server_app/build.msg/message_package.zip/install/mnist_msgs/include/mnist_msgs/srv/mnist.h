// generated from rosidl_generator_c/resource/idl.h.em
// with input from mnist_msgs:srv/Mnist.idl
// generated code does not contain a copyright notice

#ifndef MNIST_MSGS__SRV__MNIST_H_
#define MNIST_MSGS__SRV__MNIST_H_

#include "mnist_msgs/srv/mnist__struct.h"
#include "mnist_msgs/srv/mnist__functions.h"
#include "mnist_msgs/srv/mnist__type_support.h"

#endif  // MNIST_MSGS__SRV__MNIST_H_
