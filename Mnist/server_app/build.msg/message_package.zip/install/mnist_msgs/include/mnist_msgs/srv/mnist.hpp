// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MNIST_MSGS__SRV__MNIST_HPP_
#define MNIST_MSGS__SRV__MNIST_HPP_

#include "mnist_msgs/srv/mnist__struct.hpp"
#include "mnist_msgs/srv/mnist__traits.hpp"

#endif  // MNIST_MSGS__SRV__MNIST_HPP_
